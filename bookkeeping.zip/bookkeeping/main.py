#
# Домашнее задание к лекции 1.1
# «Import. Module. Package»
# Кокурникова Лилия Фаритовна, 31.03.19
#
from application import salary
salary.calculate_salary()

from application.db import people
people.get_employees()

def main():
    pass

if __name__ == '__main__':
    main()


