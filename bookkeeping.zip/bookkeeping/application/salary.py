def calculate_salary():
    pass